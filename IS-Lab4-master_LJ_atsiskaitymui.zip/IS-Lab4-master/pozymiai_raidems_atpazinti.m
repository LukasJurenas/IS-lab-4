function pozymiai = pozymiai_raidems_atpazinti(pavadinimas, pvz_eiluciu_sk)
%%  pozymiai = pozymiai_raidems_atpazinti(pavadinimas, pvz_eiluciu_sk)
% Features = pozymiai_raidems_atpazinti(image_file_name, Number_of_symbols_lines)
% taikymo pavyzdys:
% pozymiai = pozymiai_raidems_atpazinti('test_data.png', 8); 
% example of function use:
% Feaures = pozymiai_raidems_atpazinti('test_data.png', 8);
%%
% Vaizdo su pavyzdþiais nuskaitymas | Read image with written symbols
V = imread(pavadinimas);
figure(12), imshow(V) %atvaizduojam nuskaityta vaizda
%% Raidþiø iðkirpimas ir sudëliojimas á kintamojo 'objektai' celes |
%% Perform segmentation of the symbols and write into cell variable 
% RGB image is converted to grayscale
V_pustonis = rgb2gray(V); %del paprastumo tolimesnei analizei (tik 2 kanalai)
% vaizdo keitimo dvejetainiu slenkstinës reikðmës paieðka
% a threshold value is calculated for binary image conversion
slenkstis = graythresh(V_pustonis); %padalina is 255 atspalviu pagal slenksti i juoda arba balta
% pustonio vaizdo keitimas dvejetainiu(juoda balta) - pagal nustatyta
% slenkstine reiksme
% a grayscale image is converte to binary image
V_dvejetainis = im2bw(V_pustonis,slenkstis);
% rezultato atvaizdavimas
% show the resulting image
figure(1), imshow(V_dvejetainis)
% vaizde esanèiø objektø kontûrø paieðka
% search for the contour of each object
V_konturais = edge(uint8(V_dvejetainis)); %aptinka objektu konturus (kad kiekvienas simbolis būtų tinkamai atskirtas ir analizuojamas)
% rezultato atvaizdavimas
% show the resulting image
figure(2),imshow(V_konturais)
% objektø kontûrø uþpildymas 
% fill the contours
se = strel('square',7); % struktûrinis elementas (kvadratas 7x7 pikseliu) uzpildymui
V_uzpildyti = imdilate(V_konturais, se); %išplečia objektų kontūrus - tai padeda susieti gretimus taškus ar kontūrus, kurie gali būti atskirti dėl netolygumu
% rezultato atvaizdavimas
% show the result
figure(3),imshow(V_uzpildyti)
% tuðtumø objetø viduje uþpildymas
% fill the holes
V_vientisi= imfill(V_uzpildyti,'holes'); % užpildo „skyles“ objektuose (pvz A raide) - pozymiu apskaiciavimui reikia vientisu objektu
% rezultato atvaizdavimas
% show the result
figure(4),imshow(V_vientisi)
% vientisų objektų dvejetainiame vaizde numeravimas - Numeracija leidžia susieti objektus su jų požymiais
% set labels to binary image objects
[O_suzymeti Skaicius] = bwlabel(V_vientisi); %o_suzymeti - kiekvienam simboliui unikalus numeris. Skaicius - bendras simboliu skaicius
% apskaièiuojami objektø dvejetainiame vaizde pozymiai
% calculate features for each symbol
O_pozymiai = regionprops(O_suzymeti); %gali buti plotis, aukstis
% nuskaitomos poþymiø - objektu ribu koordinates - reiksmes
% find/read the bounding box of the symbol
O_ribos = [O_pozymiai.BoundingBox]; %x y, plotis aukstis. Tam kad galetume iskirpti simbolius is bendro vaizdo
% kadangi ribà nusako 4 koordinatës, pergrupuojame reikðmes
% change the sequence of values, describing the bounding box
O_ribos = reshape(O_ribos,[4 Skaicius]); % performatuoja duomenis, kad kiekvienam objektui būtų priskirta viena stulpelio eilutė, o ne visu simb duomenys vienoj eil be atskirimo
% nuskaitomos poþymiø - objektø masës centro koordinaèiø - reikðmës
% reag the mass center coordinate
O_centras = [O_pozymiai.Centroid]; %grazina y - kurioj eil simbolis, x - pozicija eilutej. (tikslas - sunku sudelioti simbolius, jei jie netiesiai issideste)
% kadangi centrà nusako 2 koordinatës, pergrupuojame reikðmes i tinkama
% formata
% group center coordinate values
O_centras = reshape(O_centras,[2 Skaicius]); %2 pozymiai, Skaicius - simboliu sk. Sutvarkom duomenis tolimesniam apdorojimui
O_centras = O_centras'; %pertvarko is eil i stulpelius
% pridedamas kiekvienam objektui vaize numeris (trecias stulpelis salia koordinaciu)
% set the label/number for each object in the image
O_centras(:,3) = 1:Skaicius;
% surûðiojami objektai pagal x koordinate - stulpeli
% arrange objects according to the column number
O_centras = sortrows(O_centras,2); %Po rūšiavimo simboliai vienoje eilutėje bus išrikiuoti vienas po kito, todėl galima lengviau juos analizuoti ir apdoroti atskirai
% rûðiojama atsiþvelgiant á pavyzdþiø eiluèiø ir raidþiø skaièiø
% sort accordign to the number of rows and number of symbols in the row
raidziu_sk = Skaicius/pvz_eiluciu_sk; %Po rūšiavimo kiekvienos eilutės simboliai bus teisinga tvarka iš kairės į dešinę.
for k = 1:pvz_eiluciu_sk
    O_centras((k-1)*raidziu_sk+1:k*raidziu_sk,:) = ...
        sortrows(O_centras((k-1)*raidziu_sk+1:k*raidziu_sk,:),3);
end
% is dvejetainio vaizdo pagal objektu ribas iskerpami vaizdo fragmentai
% cut the symbol from initial image according to the bounding box estimated in binary image
for k = 1:Skaicius
    objektai{k} = imcrop(V_dvejetainis,O_ribos(:,O_centras(k,3)));
end
% vieno is vaizdo fragmentu atvaizdavimas
% show one of the symbol's image
figure(5),
for k = 1:Skaicius
   subplot(pvz_eiluciu_sk,raidziu_sk,k), imshow(objektai{k})
end
% vaizdo fragmentai apkerpami, panaikinant fona is krastu (pagal staciakampi)
% image segments are cutt off
for k = 1:Skaicius % Skaicius = 88, jei yra 88 raidës
    V_fragmentas = objektai{k};
    % nustatomas kiekvieno vaizdo fragmento dydis
    % estimate the size of each segment
    [aukstis, plotis] = size(V_fragmentas); %grazina objekto auksti ir ploti
    
    % 1. Baltø stulpeliø naikinimas
    % eliminate white spaces
    % apskaièiuokime kiekvieno stulpelio sumà
    stulpeliu_sumos = sum(V_fragmentas,1); %paskaiciuoja pikseliu suma stulpelyje - jei visur balta - tada nereikalinga
    % naikiname tuos stulpelius, kur suma lygi aukðèiui
    V_fragmentas(:,stulpeliu_sumos == aukstis) = [];
    % perskaièiuojamas objekto dydis
    [aukstis, plotis] = size(V_fragmentas);
    % 2. Baltø eiluèiø naikinimas
    % apskaièiuokime kiekvienos seilutës sumà
    eiluciu_sumos = sum(V_fragmentas,2);
    % naikiname tas eilutes, kur suma lygi ploèiui
    V_fragmentas(eiluciu_sumos == plotis,:) = [];
    objektai{k}=V_fragmentas;% irasome vietoje neapkarpyto
end
% vieno is vaizdo fragmentu atvaizdavimas
% show the segment
figure(6),
for k = 1:Skaicius
   subplot(pvz_eiluciu_sk,raidziu_sk,k), imshow(objektai{k})
end
%%
%% Suvienodiname vaizdo fragmentø dydþius iki 70x50
%% Make all segments of the same size 70x50. Suvienodinimas užtikrina, kad visi simboliai bus pateikti tinklui vienodame formate
for k=1:Skaicius
    V_fragmentas=objektai{k};
    V_fragmentas_7050=imresize(V_fragmentas,[70,50]);
    % padalinkime vaizdo fragmentà á 10x10 dydþio dalis
    % divide each image into 10x10 size segments
    %Suskaidžius 70x50 vaizdą į 10x10 segmentus ir apskaičiavus kiekvieno segmento vidutinį šviesumą, gauname 35 požymius
    %(7 eilutės × 5 stulpeliai), kurie yra tinkami tinklui kaip įvestis.
    %kodel skaiciuojame sviesuma: Kiek pikselių segmente yra juodi ir kiek
    %– balti. Šios reikšmės apibūdina simbolio formą ir proporcijas: Pvz.
    %simbolis A turės daugiau tamsių segmentų viduryje ir šviesesnius
    %kraštus, kai simbolis I turės daugiau tamsius segmentus centre ir šviesius kraštus.
    for m=1:7
        for n=1:5
            % apskaièiuokime kiekvienos dalies vidutiná ðviesumà 
            % calculate an average intensity for each 10x10 segment
            Vid_sviesumas_eilutese=sum(V_fragmentas_7050((m*10-9:m*10),(n*10-9:n*10)));
            Vid_sviesumas((m-1)*5+n)=sum(Vid_sviesumas_eilutese);
        end
    end
    % 10x10 dydþio dalyje maksimali ðviesumo galima reikðmë yra 100
    % normuokime ðviesumo reikðmes intervale [0, 1]
    % perform normalization
    Vid_sviesumas = ((100-Vid_sviesumas)/100);
    % rezultata (pozymius) neuronu tinklui patogiau pateikti stulpeliu
    % transform features into column-vector
    Vid_sviesumas = Vid_sviesumas(:);
    % iðsaugome apskaièiuotus pozymius i bendra kintamaji
    % save all fratures into single variable
    pozymiai{k} = Vid_sviesumas;
end
